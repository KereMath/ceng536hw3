/* -*- C -*-
 * test_fb536.c -- test program for fb536 framebuffer char module
 *
 * Based on scullc from "Linux Device Drivers" by Alessandro Rubini
 * and Jonathan Corbet, published by O'Reilly & Associates.
 *
 * The source code can be freely used, adapted, and redistributed
 * in source or binary form. An acknowledgment that the code comes
 * from the book "Linux Device Drivers" is appreciated.
 *
 * Modified for CEng 536 - Fall 2025 - Homework 3
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include "fb536.h"

#define DEVICE "/dev/fb536_0"

void test_basic_operations() {
    int fd;
    unsigned char buf[100];
    int ret;

    printf("\n=== Test 1: Basic Open/Close ===\n");
    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("open");
        return;
    }
    printf("Device opened successfully\n");
    close(fd);
    printf("Device closed successfully\n");
}

void test_size_operations() {
    int fd;
    int size;

    printf("\n=== Test 2: Size Operations ===\n");
    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("open");
        return;
    }

    /* Get initial size */
    size = ioctl(fd, FB536_IOCQGETSIZE);
    printf("Initial size: %dx%d\n", size >> 16, size & 0xFFFF);

    /* Set new size */
    printf("Setting size to 500x500\n");
    ret = ioctl(fd, FB536_IOCTSETSIZE, (500 << 16) | 500);
    if (ret < 0) {
        perror("IOCTSETSIZE");
    }

    /* Verify new size */
    size = ioctl(fd, FB536_IOCQGETSIZE);
    printf("New size: %dx%d\n", size >> 16, size & 0xFFFF);

    /* Test invalid size (too small) */
    printf("Testing invalid size (100x100 - should fail)\n");
    ret = ioctl(fd, FB536_IOCTSETSIZE, (100 << 16) | 100);
    if (ret < 0) {
        printf("Correctly rejected invalid size\n");
    } else {
        printf("ERROR: Should have rejected size <= 255\n");
    }

    close(fd);
}

void test_reset() {
    int fd;
    unsigned char buf[10];

    printf("\n=== Test 3: Reset Operation ===\n");
    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("open");
        return;
    }

    /* Write some data */
    memset(buf, 0xFF, 10);
    write(fd, buf, 10);
    printf("Written 10 bytes of 0xFF\n");

    /* Reset */
    ioctl(fd, FB536_IOCRESET);
    printf("Device reset\n");

    /* Read back - should be all zeros */
    lseek(fd, 0, SEEK_SET);
    read(fd, buf, 10);
    printf("Read back after reset: ");
    int all_zero = 1;
    for (int i = 0; i < 10; i++) {
        if (buf[i] != 0) all_zero = 0;
    }
    printf("%s\n", all_zero ? "All zeros (PASS)" : "Not all zeros (FAIL)");

    close(fd);
}

void test_viewport() {
    int fd;
    struct fb_viewport vp;
    unsigned char buf[100];

    printf("\n=== Test 4: Viewport Operations ===\n");
    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("open");
        return;
    }

    /* Get default viewport */
    ioctl(fd, FB536_IOCGETVIEWPORT, &vp);
    printf("Default viewport: x=%d, y=%d, w=%d, h=%d\n",
           vp.x, vp.y, vp.width, vp.height);

    /* Set smaller viewport */
    vp.x = 100;
    vp.y = 100;
    vp.width = 200;
    vp.height = 200;
    printf("Setting viewport to: x=%d, y=%d, w=%d, h=%d\n",
           vp.x, vp.y, vp.width, vp.height);
    ret = ioctl(fd, FB536_IOCSETVIEWPORT, &vp);
    if (ret < 0) {
        perror("IOCSETVIEWPORT");
    }

    /* Verify */
    struct fb_viewport vp_check;
    ioctl(fd, FB536_IOCGETVIEWPORT, &vp_check);
    printf("Verified viewport: x=%d, y=%d, w=%d, h=%d\n",
           vp_check.x, vp_check.y, vp_check.width, vp_check.height);

    /* Write in viewport */
    memset(buf, 0xAA, 100);
    write(fd, buf, 100);
    printf("Written 100 bytes in viewport\n");

    close(fd);
}

void test_write_operations() {
    int fd;
    unsigned char buf[10];
    unsigned char rbuf[10];

    printf("\n=== Test 5: Write Operations ===\n");
    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("open");
        return;
    }

    /* Reset first */
    ioctl(fd, FB536_IOCRESET);

    /* Test SET */
    printf("Testing FB536_SET operation\n");
    ioctl(fd, FB536_IOCTSETOP, FB536_SET);
    lseek(fd, 0, SEEK_SET);
    memset(buf, 0x42, 10);
    write(fd, buf, 10);
    lseek(fd, 0, SEEK_SET);
    read(fd, rbuf, 10);
    printf("  SET: wrote 0x42, read 0x%02x %s\n", rbuf[0],
           rbuf[0] == 0x42 ? "(PASS)" : "(FAIL)");

    /* Test ADD */
    printf("Testing FB536_ADD operation\n");
    ioctl(fd, FB536_IOCTSETOP, FB536_ADD);
    lseek(fd, 0, SEEK_SET);
    memset(buf, 0x10, 10);
    write(fd, buf, 10);
    lseek(fd, 0, SEEK_SET);
    read(fd, rbuf, 10);
    printf("  ADD: 0x42 + 0x10 = 0x%02x %s\n", rbuf[0],
           rbuf[0] == 0x52 ? "(PASS)" : "(FAIL)");

    /* Test SUB */
    printf("Testing FB536_SUB operation\n");
    ioctl(fd, FB536_IOCTSETOP, FB536_SUB);
    lseek(fd, 0, SEEK_SET);
    memset(buf, 0x12, 10);
    write(fd, buf, 10);
    lseek(fd, 0, SEEK_SET);
    read(fd, rbuf, 10);
    printf("  SUB: 0x52 - 0x12 = 0x%02x %s\n", rbuf[0],
           rbuf[0] == 0x40 ? "(PASS)" : "(FAIL)");

    /* Test AND */
    printf("Testing FB536_AND operation\n");
    ioctl(fd, FB536_IOCTSETOP, FB536_AND);
    lseek(fd, 0, SEEK_SET);
    memset(buf, 0x0F, 10);
    write(fd, buf, 10);
    lseek(fd, 0, SEEK_SET);
    read(fd, rbuf, 10);
    printf("  AND: 0x40 & 0x0F = 0x%02x %s\n", rbuf[0],
           rbuf[0] == 0x00 ? "(PASS)" : "(FAIL)");

    /* Test OR */
    printf("Testing FB536_OR operation\n");
    ioctl(fd, FB536_IOCTSETOP, FB536_OR);
    lseek(fd, 0, SEEK_SET);
    memset(buf, 0xAA, 10);
    write(fd, buf, 10);
    lseek(fd, 0, SEEK_SET);
    read(fd, rbuf, 10);
    printf("  OR: 0x00 | 0xAA = 0x%02x %s\n", rbuf[0],
           rbuf[0] == 0xAA ? "(PASS)" : "(FAIL)");

    /* Test XOR */
    printf("Testing FB536_XOR operation\n");
    ioctl(fd, FB536_IOCTSETOP, FB536_XOR);
    lseek(fd, 0, SEEK_SET);
    memset(buf, 0xFF, 10);
    write(fd, buf, 10);
    lseek(fd, 0, SEEK_SET);
    read(fd, rbuf, 10);
    printf("  XOR: 0xAA ^ 0xFF = 0x%02x %s\n", rbuf[0],
           rbuf[0] == 0x55 ? "(PASS)" : "(FAIL)");

    close(fd);
}

void* waiter_thread(void* arg) {
    int fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("waiter open");
        return NULL;
    }

    struct fb_viewport vp;
    vp.x = 0;
    vp.y = 0;
    vp.width = 100;
    vp.height = 100;
    ioctl(fd, FB536_IOCSETVIEWPORT, &vp);

    printf("  Waiter thread: waiting for changes in viewport (0,0,100x100)\n");
    ioctl(fd, FB536_IOCWAIT);
    printf("  Waiter thread: woke up!\n");

    close(fd);
    return NULL;
}

void test_wait_notification() {
    pthread_t thread;
    int fd;
    unsigned char buf[10];

    printf("\n=== Test 6: Wait/Notification ===\n");

    /* Start waiter thread */
    pthread_create(&thread, NULL, waiter_thread, NULL);
    sleep(1); /* Give thread time to start waiting */

    /* Open device and write in overlapping region */
    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("writer open");
        return;
    }

    struct fb_viewport vp;
    vp.x = 50;
    vp.y = 50;
    vp.width = 100;
    vp.height = 100;
    ioctl(fd, FB536_IOCSETVIEWPORT, &vp);

    printf("  Writer: writing in viewport (50,50,100x100) - should wake waiter\n");
    memset(buf, 0x99, 10);
    write(fd, buf, 10);

    pthread_join(thread, NULL);
    printf("  Test completed\n");

    close(fd);
}

void test_overflow_underflow() {
    int fd;
    unsigned char buf[10];
    unsigned char rbuf[10];

    printf("\n=== Test 7: Overflow/Underflow Protection ===\n");
    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("open");
        return;
    }

    /* Test ADD overflow */
    ioctl(fd, FB536_IOCRESET);
    ioctl(fd, FB536_IOCTSETOP, FB536_SET);
    lseek(fd, 0, SEEK_SET);
    memset(buf, 250, 10);
    write(fd, buf, 10);

    ioctl(fd, FB536_IOCTSETOP, FB536_ADD);
    lseek(fd, 0, SEEK_SET);
    memset(buf, 100, 10);
    write(fd, buf, 10);

    lseek(fd, 0, SEEK_SET);
    read(fd, rbuf, 10);
    printf("  ADD overflow: 250 + 100 = %d %s\n", rbuf[0],
           rbuf[0] == 255 ? "(PASS - clamped to 255)" : "(FAIL)");

    /* Test SUB underflow */
    ioctl(fd, FB536_IOCRESET);
    ioctl(fd, FB536_IOCTSETOP, FB536_SET);
    lseek(fd, 0, SEEK_SET);
    memset(buf, 10, 10);
    write(fd, buf, 10);

    ioctl(fd, FB536_IOCTSETOP, FB536_SUB);
    lseek(fd, 0, SEEK_SET);
    memset(buf, 50, 10);
    write(fd, buf, 10);

    lseek(fd, 0, SEEK_SET);
    read(fd, rbuf, 10);
    printf("  SUB underflow: 10 - 50 = %d %s\n", rbuf[0],
           rbuf[0] == 0 ? "(PASS - clamped to 0)" : "(FAIL)");

    close(fd);
}

int main(int argc, char *argv[]) {
    printf("fb536 Framebuffer Driver Test Program\n");
    printf("======================================\n");

    test_basic_operations();
    test_size_operations();
    test_reset();
    test_viewport();
    test_write_operations();
    test_wait_notification();
    test_overflow_underflow();

    printf("\n=== All tests completed ===\n");
    return 0;
}
